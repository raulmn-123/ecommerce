INSERT INTO tb_products (desproduct, vlprice, vlwidth, vlheight, vllength, vlweight, desurl) VALUES
('Smartphone Motorola Moto G5 Plus', 1135.23, 15.2, 7.4, 0.7, 0.160, 'smartphone-motorola-moto-g5-plus'),
('Smartphone Moto Z Play', 1887.78, 14.1, 0.9, 1.16, 0.134, 'smartphone-moto-z-play'),
('Smartphone Samsung Galaxy J5 Pro', 1299, 14.6, 7.1, 0.8, 0.160, 'smartphone-samsung-galaxy-j5'),
('Smartphone Samsung Galaxy J7 Prime', 1149, 15.1, 7.5, 0.8, 0.160, 'smartphone-samsung-galaxy-j7'),
('Smartphone Samsung Galaxy J3 Dual', 679.90, 14.2, 7.1, 0.7, 0.138, 'smartphone-samsung-galaxy-j3');